﻿using System;
using SessionTest.Util;

namespace SessionTest
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        
        /// <summary>
        /// Evento click del boton Login
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            // obtener informacion de login
            String login = txtUser.Text;
            String password = txtPassword.Text;

            // llamar a clase estatica que valida el usuario
            if(ValidateUser.validateUserLogin(login, password, Session))
            {
                // si el usuario es valido redireccionar a welcome
                Page.Response.Redirect("Welcome.aspx");
            }
            else
            {
                // mostrar mensaje de error
                lblError.Visible = true;
            }
        }
    }
}