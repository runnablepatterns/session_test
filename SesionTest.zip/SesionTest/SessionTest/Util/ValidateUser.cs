﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SessionTest.Util
{
    public class ValidateUser
    {

        /// <summary>
        /// Metodo que valid la informacion del usuario
        /// </summary>
        /// <param name="userName">Login</param>
        /// <param name="password">Password</param>
        /// <param name="session">Session actual</param>
        /// <returns></returns>
        public static bool validateUserLogin(String userName, String password, System.Web.SessionState.HttpSessionState session)
        {
            // variables con valores por defecto
            bool validUser = false;
            UsuarioDTO userDTO = null;

            // validar el usuario
            if ((userName == "admin" & password == "123"))
            {
                // crear el DTO usando el id del usuario y el id del tipo de usuario segun la enumeracion
                userDTO = new UsuarioDTO(1, (int)UserTypeEnum.ADMIN);
                validUser = true;
            }

            if ((userName == "victor" & password == "123"))
            {
                userDTO = new UsuarioDTO(1, (int)UserTypeEnum.SUPER_ADMIN);
                validUser = true;
            }

            if ((userName == "carlos" & password == "123"))
            {
                userDTO = new UsuarioDTO(1, (int)UserTypeEnum.ESTUDIANTE);
                validUser = true;
            }

            // agregar DTO al usuario
            session.Add("usuario", userDTO);

            // retornar resultado
            return validUser;
        }
    }
}