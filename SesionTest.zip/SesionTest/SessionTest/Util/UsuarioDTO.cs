﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SessionTest.Util
{
    public class UsuarioDTO
    {
        public int UserID { get; set; }
        public int UserTypeID { get; set; }


        public UsuarioDTO(int userId, int userTypeId)
        {
            this.UserID = userId;
            this.UserTypeID = userTypeId;
        }
    }

    public enum UserTypeEnum
    {
        ADMIN = 1,
        SUPER_ADMIN = 2,
        ESTUDIANTE = 3,
        GESTOR = 4
    }
}