﻿using System;
using SessionTest.Util;

namespace SessionTest
{
    public partial class Welcome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        /// <summary>
        /// Evento click del boton TipoUsuario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnTipoUsuario_Click(object sender, EventArgs e)
        {
            // obtener el DTO de la sesion
            UsuarioDTO usuarioDTO = (UsuarioDTO)Session["usuario"];

            // si el DTO tiene un valor en la sesion
            if(usuarioDTO != null)
            {
                // obtener el tipo de usuario
                lblTipoUsuario.Text = ((UserTypeEnum)usuarioDTO.UserTypeID).ToString();
            }
            else
            {
                lblTipoUsuario.Text = "Sin datos en sesion";
            }
        }
    }
}